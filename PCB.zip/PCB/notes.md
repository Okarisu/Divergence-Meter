# Poznámky k deskám

## Rozměry

* Horní deska:
    * vnitřní část: 113 mm x 30,5 mm